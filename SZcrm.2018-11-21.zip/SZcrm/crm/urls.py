from django.conf.urls import url, include
from crm import views
urlpatterns = [

    url(r'^login/', views.LoginViews.as_view(), name='login'),
    url(r'^reg/', views.RegViews.as_view(), name='reg'),
    url(r'^index/', views.IndexViews.as_view(), name='index'),
    url(r'^index2/', views.index, name='index1'),
    url(r'^check_user/', views.check_user, name='check_user'),
    url(r'^logout/', views.Logout.as_view(), name='logout'),
    url(r'^change/', views.ChangeVires.as_view(), name='change'),
]
