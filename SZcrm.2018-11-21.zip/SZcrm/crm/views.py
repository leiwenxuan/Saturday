from django.shortcuts import render, redirect, HttpResponse
from django.views import View
from django.contrib import auth
from crm.forms import RegisteredForm
from crm.models import UserProfile, Customer
from django.urls import reverse
from django.http import JsonResponse

# 导入日志
import logging
logger = logging.getLogger(__name__)
# Create your views here.

class LoginViews(View):
    def get(self, request):
        return render(request, 'login2.html')


    def post(self, request):
        stu_name = request.POST.get('stu_name')
        stu_pwd = request.POST.get('stu_pwd')
        # 判断checkbox 是否选中
        is_check = (request.POST.get('check_un') == 'ok')
        # 验证密码是否正确
        user_obj = auth.authenticate(request, email=stu_name, password=stu_pwd)
        if user_obj:
            print('7'*20)
            # 把登陆用户加入
            auth.login(request, user_obj)
            # 判断是否选中７天免登陆
            if is_check:
                request.session.set_expiry(7*24*60*60)
            else:
                request.session.set_expiry(0)
            next_url = reverse('crm:index')
            print(next_url)
            return redirect(next_url)
        else:
            print('-'*20)
            return render(request, 'login2.html', {"error_msg": '用户名密码错误'})



class RegViews(View):
    def get(self, request):
        form_obj = RegisteredForm()
        print('@'*80)
        return render(request, 'reg.html', {"form_obj": form_obj})

    def post(self, request):

        # 实例化一个form　对象, 接受request.post
        form_obj = RegisteredForm(request.POST)

        # 创建一个ajax 验证字典
        res = {'code': 0}
        # 校验是否通过验证
        if form_obj.is_valid():
            # 清理数据　 cleaned_data() 数据里面多出了确认密码的选项，ｐｏｐ出去
            data = form_obj.cleaned_data
            data.pop("re_password")
            # 创建用户
            UserProfile.objects.create_user(**data)
            # 打入日志
            logger.info(data)
            # 规范化的地址
            next_url = reverse('crm:login')
            print(next_url)
            res['url'] = next_url
            return JsonResponse(res)
        else:
            print('&' * 80, 'new')
            res['code'] = 1
            # python json 不能传对象
            res['essor_msg'] = form_obj.errors
            return JsonResponse(res)


class IndexViews(View):
    def get(self, request):
        customer_lsit = Customer.objects.all()
        return render(request, 'index.html', {"customer_list": customer_lsit})



def check_user(request):
    ''' 检测input 输入是否可靠'''
    form_obj = RegisteredForm(request.POST)
    res = {'code': 0}
    if request.method == "POST":
        # 解析　request.POST 形成一个可靠数据
        for key, val in request.POST.items():
            # 字段唯一判断
            if key in ['phone', 'email']:
                data = {key: val}
                is_user = UserProfile.objects.filter(**data)
            # print(is_user)
            # 如果is_user 存在返回错误消息
                if is_user:
                    res['code'] = 1
                    res['error_msg'] = '该选项已存在！'
                    print('!' * 80)
                    return JsonResponse(res)
            if  val is None:
                print('%' * 20)
                res['code'] = 1
                res['error_msg'] = '请正确输入！'
                print('!' * 80)
                return JsonResponse(res)

    return JsonResponse(res)


class Logout(View):
    def get(self, request):
        return render(request, 'logout.html')
    def post(self, request):
        print('+' * 20)
        if request.method == 'POST':
            from django.contrib import auth
            auth.logout(request)
            print('%' * 20)
            next_change = reverse('crm:login')
            return JsonResponse({'code': 0, 'url': next_change})


class ChangeVires(View):
    def get(self, request):
        return render(request, 'change.html')



def index(request):
    '''
    程序分析：１．获取前端点击的页数
            2. 计算总的页数, 设置页面显示的数据量
            3. 计算要用多少页来显示　divmod(table_count, per_page)　商和余
            4. 处理下不是正确的页数
            5. 设置一个　页面显示多少页码
            ６. 处理页面显示各种特殊情况
            7. 拼接html 代码
         customer_lsit = Customer.objects.all()
        return render(request, 'index.html', {"customer_list": customer_lsit})
    :param request:
    :return:
    '''
    # 从URL获取参数
    page_num = request.GET.get("page")
    print(page_num, type(page_num))

    # 总数据量
    table_count = Customer.objects.all().count()
    print(table_count)

    # 每一页显示多少数据
    per_page = 10

    # 总共需要多少页码来展示 总页码数减去每页显示的数
    total_page, m = divmod(table_count, per_page)
    if m:
        # 如果余数为真，　总共需要商加１
        total_page += 1
    try:
        page_num = int(page_num)
        # 如果输入的页码超过了最大的页码书默认显示最后一页
        if page_num > total_page:
            page_num = total_page
    except Exception as e:
        # 当输入的页码不是数字类型返回第一页
        page_num = 1

    # 定义两个变量保存数据从哪儿取到哪儿
    data_start = (page_num-1)*10
    data_end = page_num *10

    # 页面显示的多少页码
    max_page = 11
    # 如果总的数据量没有 显示的页码大， 显示总数据
    if total_page < max_page:
        max_page = total_page

    half_max_page = max_page // 2
    # 页面展示的页码从哪儿开始
    page_start = page_num - half_max_page

    # 页面展示的页码到哪里结束
    page_end = page_num + half_max_page

    # 如果当前页减去一半 比1还小
    if page_start <= 1:
        page_start = 1
        page_end = max_page
    # 如果 当前页加一半比总页码数还大
    if page_end >= total_page:
        page_end = total_page
        page_start = total_page - max_page + 1
    # 显示的数据源
    customer_lsit = Customer.objects.all()[data_start:data_end]

    # 拼接分页代码
    html_str_list = []
    html_str_list.append('<li><a href="/crm/index2/?page=1">首页</a></li>')

    # 判断一下 如果是第一页, 就没有上一页
    if page_num <= 1:
        html_str_list.append('<li class="disabled"><a href="#"><span aria-hidden="true">&laquo;</span></a></li>'.format(page_num-1))
    else:
        # 加上一个上一页标签
        html_str_list.append('<li ><a href="/crm/index2/?page={}"><span aria-hidden="true">&laquo;</span></a></li>'.format(page_num-1))

    for i in range(page_start, page_end+1):
        # 如果是当前页就加一个acticv 样式
        if i == page_num:
            tmp = '<li class="active"><a href="/crm/index2/?page={0}">{0}</a></li>'.format(i)
        else:
            tmp = '<li ><a href="/crm/index2/?page={0}">{0}</a></li>'.format(i)

        html_str_list.append(tmp)


    # 加以一个下一页的按钮
    # 如果是最少一页
    if page_num >= total_page:
        html_str_list.append('<li class="disabled"><a href="#"><span aria-hidden="true">&raquo;</span></a></li>')
    else:
        html_str_list.append('<li><a href="/crm/index2/?page={}"><span aria-hidden="true">&raquo;</span></a></li>'.format(page_num+1))
    # 加最后一页
    html_str_list.append('<li><a href="/crm/index2/?page={}">尾页</a></li>'.format(total_page))

    page_html = "".join(html_str_list)


    return render(request, 'index.html', {'customer_list': customer_lsit, 'page_list': page_html })




