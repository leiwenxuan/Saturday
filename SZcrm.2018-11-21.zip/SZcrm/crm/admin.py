from django.contrib import admin
from crm import models

# Register your models here.

admin.site.register(models.UserProfile)
admin.site.register(models.Campuses)
# admin.site.register(models.ClassList)
admin.site.register(models.Customer)

@admin.register(models.ClassList)
class ClassListAdmin(admin.ModelAdmin):
    list_display = ('course', 'semester', 'campuses', 'price', 'show_campuses')






