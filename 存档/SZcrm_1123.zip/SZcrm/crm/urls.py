from django.conf.urls import url
from crm import views

urlpatterns = [

    url(r'^login/', views.LoginViews.as_view(), name='login'),
    url(r'^log/', views.login, name='log'),

    url(r'^reg/', views.RegViews.as_view(), name='reg'),
    url(r'^index1/', views.IndexViews.as_view(), name='index1'),
    url(r'^cus_list/', views.IndexViews.as_view(), name='cus_list'),
    url(r'^check_user/', views.check_user, name='check_user'),
    url(r'^logout/', views.Logout.as_view(), name='logout'),
    url(r'^change/', views.ChangeVires.as_view(), name='change'),
    url(r'^add/', views.Add_cus.as_view(), name='add_cus'),
    url(r'^get_valid_img.png/', views.get_valid_img),

    # 极验滑动验证码 获取验证码的url
    url(r'^pc-geetest/register/', views.get_geetest),

    url(r'^private/', views.IndexViews.as_view(), name='pirvate'),

    url(r'record_list/', views.record_list, name='record_list'),
    url(r'change_recode/', views.change_record, name='change_record'),

]
