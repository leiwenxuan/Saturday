'''
    设置session　数据
'''
from SZcrm import settings


def init(request, user_obj):
    # 1.查询用户权限
    # 2.把查询的url 添加到session 里面
    url_list = user_obj.roles.all().values(
        'permissions__url',
        'permissions__title',
        'permissions__name',
        'permissions__show',
        'permissions__menu_id',
        'permissions__menu__title',
        'permissions__menu__icon',
        'permissions__menu__weight',
    ).distinct()  # 返回的QuerySet对象，没个元素都是元组
    # 3.把查询的ｕｒｌ加入列表
    # 取到url_list
    #  permissions_list = [permissions['permissions__url'] for permissions in url_list]
    permissions_list = {}
    # 存放菜单列表
    menu_list = {}
    for item in url_list:
        dict_key = item['permissions__name']
        permissions_list[dict_key] = {
            'url': item['permissions__url'],
            'menu_id': item['permissions__menu_id'],
        }

        # 取出菜单列表　
        p_id = item['permissions__menu_id']
        if p_id not in menu_list:
            menu_list[p_id] = {
                'id': item['permissions__menu_id'],
                'title': item['permissions__menu__title'],
                'weight': item['permissions__menu__weight'],
                'children': [{
                    'title': item['permissions__title'],
                    'url': item['permissions__url'],
                    'show': item['permissions__show'],
                }],
            }
        else:
            menu_list[p_id]['children'].append(
                {
                    'title': item['permissions__title'],
                    'url': item['permissions__url'],
                    'show': item['permissions__show'],
                }
            )

    print('url', permissions_list)
    print('菜单', menu_list)
    session_key = getattr(settings, 'PERMISSION_URL_KEY', 'permissions_url')
    menu_key = getattr(settings, 'SECRET_MENU', 'menu_list')

    # 设置session, 存取menu列表
    request.session[menu_key] = menu_list
    # 设置session, 存取ｕｒｌ列表
    request.session[session_key] = permissions_list
