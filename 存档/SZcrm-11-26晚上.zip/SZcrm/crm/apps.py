from django.apps import AppConfig


class CrmConfig(AppConfig):
    name = 'crm'
    verbose_name = 'ＣＲＭ管理系统'
    verbose_name_plural = 'ＣＲＭ管理系统'
