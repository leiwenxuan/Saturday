from django.apps import AppConfig


class TeacherConfig(AppConfig):
    name = 'teacher'
    verbose_name = '学生管理'
    verbose_name_plural = '学生管理'