from django.apps import AppConfig


class BookConfig(AppConfig):
    name = 'book'
    verbose_name = '图书管理'
    verbose_name_plural = '图书管理'