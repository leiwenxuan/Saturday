from django import template
from SZcrm import settings
import re
register = template.Library()


@register.inclusion_tag(filename='rbac/menu.html')
def meun_list(request):
    # １． 获取当前的url
    new_url = request.path_info
    # ２． 获取session　储存的session　key
    meun_key = getattr(settings, 'SECRET_MENU', 'menu_list')
    # 3. 获取session 里面的权限限定
    meun_list = request.session.get(meun_key)
    # 4.　循环判断：如果当前的ｕｒｌ在权限里面加一个css样式，
    for meun in meun_list:
        if re.match(r'^{}$'.format(meun['url']), new_url):
            meun['class'] = 'active'
    return {'menu_list': meun_list}
